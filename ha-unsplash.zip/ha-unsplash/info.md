# Unsplash for Home Assistant

Turn any public Unsplash collection into a rotating `image` entity. Use it as a dashboard background, View Assist background, WallPanel slideshow source, or anywhere else an image entity works.

## What you get

- One image entity per Unsplash collection you add
- Configurable refresh interval (default: every 15 minutes)
- Photographer credit exposed as state attributes for compliant attribution
- Automatic Unsplash download-tracking — keeps you compliant with the API terms
- Filter by orientation (landscape / portrait / squarish)

## Quick start

1. Get a free Access Key at [unsplash.com/developers](https://unsplash.com/developers)
2. Install via HACS, restart Home Assistant
3. **Settings → Devices & Services → Add Integration → Unsplash** → paste your key
4. Click **Configure** on the integration → **Add a collection** → enter a Collection ID (e.g. `8975107` from `https://unsplash.com/collections/8975107`)

That's it. The entity rotates automatically on your configured interval.

See the [README](https://github.com/kedinger/ha-unsplash) for full setup details, dashboard examples, and View Assist integration patterns.
